/*Lab 8: Polymorphism
In this lab you will derive an asbtract class called Employee from the Person class and derive two concrete classes from Employee 
called Salary Employee and HourlyEmployee. The subclasses of Employee will provide different implementations of the abstract getEarnings() method.  
//Step 1: derive the two new classes SalaryEmployee and HourlyEmployee.     
 * @author ravneetkaur0125
 */
package Lab8a;

public class HourlyEmployee extends Employee {//this is new class and is inherited from Employee class
    //HourlyEmployee is a type of Employee who is a person, hence polymorphism

    // Declaring the parameters of HourlyEmployee class as per the UML
    private float hourlyRate;
    private float hoursWorked;

    public HourlyEmployee() {
        /*Creating an empty constructor to initialize the class, though we don't need to write this explicitly 
        - complier will create on its own */
    }

    //Constructor- Adding the constructor to initialize the class 
    //- using Super keyboard to inherit properties of parent class
    public HourlyEmployee(float hourlyRate, float hoursWorked, int employeeNo, String jobDescription, String lastName, String firstName, char middleInit, String phoneNumber, Address address) {
        super(employeeNo, jobDescription, lastName, firstName, middleInit, phoneNumber, address);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
        this.setHoursWorked(hoursWorked);
    }

    //Getter for the field hourly rate
    public float getHourlyRate() {
        return hourlyRate;
    }

    //Setter for the field hourly rate
    public void setHourlyRate(float hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    //Getter for the field hours worked
    public float getHoursWorked() {
        return hoursWorked;
    }

    //Setter for the field hours worked
    public void setHoursWorked(float hoursWorked) {
        //making sure that the hours worked calue isn't negative
        if (hoursWorked < 0) {
            this.hoursWorked = 0;
        } else {
            this.hoursWorked = hoursWorked;
        }
        this.hoursWorked = hoursWorked;
    }
    
    @Override
    public String getEmployeeType() {
        return "Hourly";
    }
    
    @Override //makes code more clear and understandable
    public double getEarnings() {//to override the getEarnings abstract method from Employee class
        double earnings = 0;

        if (hoursWorked > 80) {
            earnings = (hoursWorked - 80) * hourlyRate * 1.5 + 80 * hourlyRate; //calculating earnings if hours worked are more than 80
        } else {
            earnings = hoursWorked * hourlyRate; //calculating total earnings
        }
        return earnings;
    }
}
