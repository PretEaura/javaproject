/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab8a;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class TimeTrackingReportUI extends JFrame {
    private JTable reportTable;

    public TimeTrackingReportUI() {
        setTitle("Time Tracking Report");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 400);
        setLayout(new BorderLayout());

        // Table Model
        String[] columnNames = {"Employee ID", "Employee Name", "Employee Type", "Date", "Total Time"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        reportTable = new JTable(tableModel);

        // Add components
        add(new JScrollPane(reportTable), BorderLayout.CENTER);

        JButton loadButton = new JButton("Load Report");
        loadButton.addActionListener(e -> loadReport(tableModel));
        add(loadButton, BorderLayout.SOUTH);

        //JButton backButton = new JButton("Back");
        //add(backButton, BorderLayout.SOUTH);
        
        setVisible(true);
    }

    private void loadReport(DefaultTableModel tableModel) {
        String dbUrl = "jdbc:mysql://localhost:3306/employee";
        String dbUser = "root";
        String dbPassword = "root";

        String reportQuery = "SELECT " +
                "e.employee_no AS `Employee ID`, " +
                "CONCAT(p.first_name, ' ', p.last_name) AS `Employee Name`, " +
                "e.employee_type AS `Employee Type`, " +
                "DATE(t.in_time) AS `Date`, " +
                "SEC_TO_TIME(SUM(TIMESTAMPDIFF(SECOND, t.in_time, t.out_time))) AS `Total Time` " +
                "FROM employee e " +
                "JOIN timetracking t ON e.employee_id = t.employee_id " +
                "JOIN person p ON p.person_id = e.person_id " +
                "GROUP BY e.employee_id, `Date` " +
                "ORDER BY `Date`, e.employee_id";

        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(reportQuery)) {

            // Clear existing rows
            tableModel.setRowCount(0);

            // Populate table
            while (rs.next()) {
                int employeeId = rs.getInt("Employee ID");
                String employeeName = rs.getString("Employee Name");
                String employeeType = rs.getString("Employee Type");
                Date date = rs.getDate("Date");
                String totalTime = rs.getString("Total Time");

                tableModel.addRow(new Object[]{employeeId, employeeName, employeeType, date, totalTime});
            }

            JOptionPane.showMessageDialog(this, "Report Loaded Successfully!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new TimeTrackingReportUI();
    }
}

