package Lab8a;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class EmployeeListPage extends JFrame {
    public EmployeeListPage() {
        setTitle("Employee List");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel to hold table and controls
        JPanel mainPanel = new JPanel(new BorderLayout());

        // Panel for the table
        JPanel tablePanel = new JPanel(new BorderLayout());

        // Table to display employee data
        JTable employeeTable = new JTable();
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{
                "Employee No", "First Name", "Middle Name", "Last Name", 
                "Phone Number", "Street", "City", "Postal Code", 
                "Job Title", "Employee Type", "Salary", "Hourly Rate"
        });
        employeeTable.setModel(model);

        // Customize the header
        JTableHeader tableHeader = employeeTable.getTableHeader();
        tableHeader.setBackground(new Color(0, 0, 128)); // Navy blue
        tableHeader.setForeground(Color.WHITE);          // White text
        tableHeader.setFont(new Font("Arial", Font.BOLD, 14));

        // Customize rows
        employeeTable.setDefaultRenderer(Object.class, new TableCellRenderer() {
            private final JLabel label = new JLabel();

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                label.setText(value != null ? value.toString() : "");
                label.setOpaque(true);

                if (isSelected) {
                    label.setBackground(new Color(135, 206, 250)); // Light blue for selected rows
                    label.setForeground(Color.BLACK);
                } else {
                    label.setBackground(row % 2 == 0 ? Color.LIGHT_GRAY : Color.WHITE); // Alternate grey and white rows
                    label.setForeground(Color.BLACK);
                }
                return label;
            }
        });

        // Fetch data from the database
        fetchEmployeeData(model);

        // Add table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(employeeTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        // Control panel for buttons
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        // Back button
        JButton backButton = new JButton("Back");
        backButton.addActionListener((ActionEvent e) -> {
            // Navigate back to the dashboard
            new Dashboard().setVisible(true);
            dispose(); // Close the current window
        });

        controlPanel.add(backButton);

        // Add panels to the main panel
        mainPanel.add(controlPanel, BorderLayout.NORTH);  // Add control panel at the top
        mainPanel.add(tablePanel, BorderLayout.CENTER);   // Add table panel at the center

        // Add main panel to the frame
        add(mainPanel);
    }

    private void fetchEmployeeData(DefaultTableModel model) {
        String query = "SELECT   e.employee_no,    p.first_name, p.middle_init, p.last_name, p.phone_number, a.street, a.city, a.postal_code, e.job_title, e.employee_type, e.salary, e.hourly_rate FROM employee e  JOIN person p ON e.person_id = p.person_id LEFT JOIN address a ON p.address_id = a.address_id";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "root");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("employee_no"),
                        rs.getString("first_name"),
                        rs.getString("middle_init"),
                        rs.getString("last_name"),
                        rs.getString("phone_number"),
                        rs.getString("street"),
                        rs.getString("city"),
                        rs.getString("postal_code"),
                        rs.getString("job_title"),
                        rs.getString("employee_type"),
                        rs.getBigDecimal("salary"),
                        rs.getBigDecimal("hourly_rate")
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error fetching employee data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EmployeeListPage().setVisible(true));
    }
}
