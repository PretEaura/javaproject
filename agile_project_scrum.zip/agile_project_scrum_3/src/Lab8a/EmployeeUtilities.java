/*Lab 8: Polymorphism
Step 2: Now modify the EmployeeUtilities getData() method (EmployeeUtilities created in Lab7 that manipulates an array of Employees 
for a JFrame presentation layer):
 * @author ravneetkaur0125
 */
package Lab8a;

import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;


public class EmployeeUtilities {
    private Connection conn;
    // Declaring the parameters of EmployeeUtilities class as per the UML
    private Employee[] employees; //Array of Employee class
    private int current; //pointer defined to point to the current employee record

    public EmployeeUtilities() {//Constructor of the Employee Utilities class
        //Initializing the current employee record pointer to zero
        current = 0;
         try{
             Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "root");
             } 
          catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        //Calling the getData method to initialize array elements for Employee Utilities class
        getData();
    }
    
    

    
    //Method to fetch the details of next employee in the records base with circular reference
    public Employee getNext() {
        current++;
        //check if the current record is the last employee in the list, then reset the pointer to start
        if (current >= employees.length) {
            current = 0;
        }
        return employees[current];
    }

    //Method to fetch the details of previous employee in the records base with circular reference
    public Employee getPrevious() {
        current--;
        //check if the current record is the first employee in the list, then reset the pointer to last
        if (current < 0) {
            current = employees.length - 1;
        }
        return employees[current];
    }

    //Method to fetch the details of current employee record pointed by the current variable
    public Employee getCurrent() {
        return employees[current];
    }
    
   public Employee getCurrentEmployee() {
    // Assuming "HourlyEmployee" and "SalaryEmployee" are concrete subclasses of "Employee"
    return new HourlyEmployee(25.0f, 0, 1, "Software Developer", 
                              "Doe", "John", 'A', "123-456-7890", 
                              new Address("123 Street", "City", "State", "12345"));
    }
     /*
   public Employee getCurrentEmployee() {
    return new SalaryEmployee(60000.0f, 2, "Manager", 
                              "Brown", "Robert", 'C', "111-222-3333", 
                              new Address("789 Road", "Smallville", "StateY", "34567"));
}
   If you’re retrieving the employee dynamically (e.g., based on a logged-in user), replace the hardcoded data with queries or session-based logic.
   
   */
    public void saveTimeTracking(int empNumber, Timestamp in, Timestamp out) throws SQLException {
        String fetchEmployeeIdSql = "SELECT employee_id FROM employee WHERE employee_no = ?";
        String sql = "INSERT INTO TimeTracking (employee_id, in_time, out_time) VALUES (?, ?, ?)";
        System.out.println("SQ: " + sql);
        
        if (conn == null || conn.isClosed()) {
            System.out.println("Database connection is not established.");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "root");
        }

        if (conn == null || conn.isClosed()) {
            System.out.println("Database connection is not established yet.");
           
        }
        
        int empId = -1; // Variable to store the employee ID
        
        // Fetch employee ID
        try (PreparedStatement psFetch = conn.prepareStatement(fetchEmployeeIdSql)) {
            psFetch.setInt(1, empNumber);
            ResultSet rs = psFetch.executeQuery();
            if (rs.next()) {
                empId = rs.getInt("employee_id");
            } else {
                System.out.println("No employee found with number: " + empNumber);
                return;
            }
        }
        
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, empId);
            ps.setTimestamp(2, in);
            ps.setTimestamp(3, out);
            
             
            ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public List<TimeTracking> getTimeTracking(int empId) {
        List<TimeTracking> timeData = new ArrayList<>();
        String sql = "SELECT * FROM TimeTracking WHERE employee_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, empId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                TimeTracking record = new TimeTracking(
                        rs.getInt("id"),
                        rs.getInt("employee_id"),
                        rs.getTimestamp("in_time"),
                        rs.getTimestamp("out_time")
                );
                timeData.add(record);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return timeData;
    }

    public void saveSalary(int empId, float hoursWorked, float salary) {
        String sql = "INSERT INTO Salary (employee_id, hours_worked, calculated_salary, pay_date) VALUES (?, ?, ?, CURDATE())";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, empId);
            ps.setFloat(2, hoursWorked);
            ps.setFloat(3, salary);
            ps.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public List<SalaryRecord> getSalaryRecords(int empId) {
        List<SalaryRecord> salaryData = new ArrayList<>();
        String sql = "SELECT * FROM Salary WHERE employee_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, empId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                SalaryRecord record = new SalaryRecord(
                        rs.getInt("id"),
                        rs.getInt("employee_id"),
                        rs.getFloat("hours_worked"),
                        rs.getFloat("calculated_salary"),
                        rs.getDate("pay_date")
                );
                salaryData.add(record);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return salaryData;
    }
    
    //Method to fetch the employee details using the Employee Number
    public Employee getEmployeeById(int id) {
        Employee e = null;
        //Using for loop to triage through Employee array
        for (int i = 0; i < employees.length; i++) {
            //Checking if the user entered Employee Id is equal to the Employee Number in array
            if (employees[i].getEmployeeNo() == id) {
                //Assigning the employee details to Employee datatype variable
                e = employees[i];
                //Setting the current pointer to the searched record index
                current = i;
            }
        }
        return e;
    }

    //Method to update Employee details basis the user inputs
    public void updateEmployee(Employee e) {
        employees[current] = e;
    }

    //Method to initialize array elements for Employee class
    public void getData() {
        String jdbcURL = "jdbc:mysql://localhost:3306/employee"; 
        String dbUser = "root"; 
        String dbPassword = "root"; 

        ArrayList<Address> addressList = new ArrayList<>();
        ArrayList<Employee> employeeList = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword)) {
            // Fetch Address data
            String addressQuery = "SELECT address_id, street, city, province, postal_code FROM Address";
            try (PreparedStatement addressStmt = connection.prepareStatement(addressQuery);
                 ResultSet addressRs = addressStmt.executeQuery()) {

                while (addressRs.next()) {
                    Address address = new Address(
                        addressRs.getString("street"),
                        addressRs.getString("city"),
                        addressRs.getString("province"),
                        addressRs.getString("postal_code")
                    );
                    addressList.add(address);
                }
            }

            // Fetch Employee and Person data
            String employeeQuery = "SELECT e.employee_no, e.job_title, e.employee_type, e.salary, e.hourly_rate, e.hours_worked, p.last_name, p.first_name, p.middle_init, p.phone_number, p.address_id  FROM Employee e JOIN Person p ON e.person_id = p.person_id";
            try (PreparedStatement employeeStmt = connection.prepareStatement(employeeQuery);
                 ResultSet employeeRs = employeeStmt.executeQuery()) {

                while (employeeRs.next()) {
                    String jobTitle = employeeRs.getString("job_title");
                    String lastName = employeeRs.getString("last_name");
                    String firstName = employeeRs.getString("first_name");
                    char middleInit = employeeRs.getString("middle_init").charAt(0);
                    String phoneNumber = employeeRs.getString("phone_number");
                    int addressId = employeeRs.getInt("address_id");

                    // Get corresponding Address object by address ID
                    Address address = addressList.get(addressId - 1); // Assuming address_id starts from 1

                    // Check employee type and instantiate the correct subclass
                    String employeeType = employeeRs.getString("employee_type");
                    Employee employee;
                    if ("SalaryEmployee".equals(employeeType)) {
                        float salary = employeeRs.getFloat("salary");
                        employee = new SalaryEmployee(salary, employeeRs.getInt("employee_no"), jobTitle,
                            lastName, firstName, middleInit, phoneNumber, address);
                    } else { // HourlyEmployee
                        float hourlyRate = employeeRs.getFloat("hourly_rate");
                        int hoursWorked = employeeRs.getInt("hours_worked");
                        employee = new HourlyEmployee(hourlyRate, hoursWorked, employeeRs.getInt("employee_no"),
                            jobTitle, lastName, firstName, middleInit, phoneNumber, address);
                    }
                    employeeList.add(employee);
                }
            }

            // Convert ArrayList to array for the employees field
            employees = employeeList.toArray(new Employee[0]);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
