/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab8a;

/**
 *
 * @author Preetul
 */
import java.sql.Date;

public class SalaryRecord {
    private int id;
    private int employeeId;
    private float hoursWorked;
    private float calculatedSalary;
    private Date payDate;

    // Constructor
    public SalaryRecord(int id, int employeeId, float hoursWorked, float calculatedSalary, Date payDate) {
        this.id = id;
        this.employeeId = employeeId;
        this.hoursWorked = hoursWorked;
        this.calculatedSalary = calculatedSalary;
        this.payDate = payDate;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public float getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(float hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    public float getCalculatedSalary() {
        return calculatedSalary;
    }

    public void setCalculatedSalary(float calculatedSalary) {
        this.calculatedSalary = calculatedSalary;
    }

    public Date getPayDate() {
        return payDate;
    }

    public void setPayDate(Date payDate) {
        this.payDate = payDate;
    }

    @Override
    public String toString() {
        return "SalaryRecord{" +
                "id=" + id +
                ", employeeId=" + employeeId +
                ", hoursWorked=" + hoursWorked +
                ", calculatedSalary=" + calculatedSalary +
                ", payDate=" + payDate +
                '}';
    }
}
