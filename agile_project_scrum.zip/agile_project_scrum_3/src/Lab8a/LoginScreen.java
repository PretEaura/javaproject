/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab8a;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.awt.*;

public class LoginScreen extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginScreen() {
        setTitle("Login");
        setSize(700, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Setting up layout and padding
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Add padding around components
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Username label and field
        JLabel usernameLabel = new JLabel("Username:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(usernameLabel, gbc);

        usernameField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(usernameField, gbc);

        // Password label and field
        JLabel passwordLabel = new JLabel("Password:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(passwordLabel, gbc);

        passwordField = new JPasswordField(20);
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(passwordField, gbc);

        // Login button
        JButton loginButton = new JButton("Login");
        loginButton.setPreferredSize(new Dimension(100, 30)); // Make button larger
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(loginButton, gbc);
        
       
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                if (authenticateUser(username, password)) {
                    //JOptionPane.showMessageDialog(null, "Login successful!");
                    dispose(); // Close login window
                    //showLoginSuccessMessage();
                    //new EmployeeManager().setVisible(true); // Open details screen on successful login
                    new Dashboard().setVisible(true);  // Open Dashboard screen on successful login
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid credentials. Please try again.");
                }
            }
        });

        

        add(panel);
    }
    
    private boolean authenticateUser(String username, String password) {
        // JDBC connection and authentication logic
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "root");
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM login WHERE username = ? AND password = ?")) {
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            return rs.next(); // If a record is found, the credentials are valid

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    private void showLoginSuccessMessage() {
        // Display login success message with a delay to auto-close
        JOptionPane pane = new JOptionPane("Login successful!", JOptionPane.INFORMATION_MESSAGE);
        JDialog dialog = pane.createDialog(this, "Success");
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setVisible(true);

        // Use Timer to close the dialog after 2 seconds
        Timer timer = new Timer(2000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose(); // Close the message dialog
                dispose();        // Close the login window
                new EmployeeManager().setVisible(true); // Open details screen on successful login
            }
        });
        timer.setRepeats(false); // Execute only once
        timer.start();
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginScreen().setVisible(true);
        });
    }
}

