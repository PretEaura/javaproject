/**Lab 8: Polymorphism
 * This is Step 2 of the program in Lab6 and carried over to Lab7 and Lab8
 * @author RavneetKaur0125
 */
package Lab8a;
public class Person {

    // Declaring the parameters of Person class as per the UML
    private String lastName;
    private String firstName;
    private char middleInit;
    private String phoneNumber;
    private Address address;  //declaring the address variable of the class type Address - this is Composition

    public Person() {
          /*Creating an empty constructor to initialize the class as compiler will not generate itself 
    since we have a constructor defined in the program */
    }

    //Constructor #2 - retaining the old constructor version 2 so that it doesn't create issues with the code
    public Person(String lastName, String firstName, char middleInit, String phoneNumber) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleInit = middleInit;
        this.phoneNumber = phoneNumber;
    }

     //Constructor #1 - retaining the old constructor version 1 so that it doesn't create issues with the code
    public Person(String lastName, String firstName, char middleInit) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleInit = middleInit;
    }

    //Constructor #3- Adding a new constructor for implementing the change for Address while retaining the old ones
    public Person(String lastName, String firstName, char middleInit, String phoneNumber, Address address) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleInit = middleInit;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    //Getter for address variable with return type as Address
    public Address getAddress() {
        return address;
    }

    //Setter for address variable with passed parameter type as Address
    public void setAddress(Address address) {
        this.address = address;
    }

     //Getter for Phone Number field
    public String getPhoneNumber() {
        return phoneNumber;
    }

     //Setter for Phone Number field
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

     //Getter for Last Name field
    public String getLastName() {
        return lastName;
    }

     //Setter for Last Name field
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
     //Getter for First Name field
    public String getFirstName() {
        return firstName;
    }

     //Setter for First Name field
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

     //Getter for Middle Initial field
    public char getMiddleInit() {
        return middleInit;
    }

     //Setter for Middle Initial field
    public void setMiddleInit(char middleInit) {
        this.middleInit = middleInit;
    }

    //Getter for Full Name field with definition
    public String getFullName() {
        return lastName + ", " + firstName + ", " + middleInit + ". ";
    }
}
