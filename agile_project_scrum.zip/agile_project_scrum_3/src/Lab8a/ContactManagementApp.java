package Lab8a;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ContactManagementApp {

    private EmployeeUtilities employeeUtilities;

    public ContactManagementApp() {
        employeeUtilities = new EmployeeUtilities(); // Initialize employee utilities
    }

    public void createAndShowGUI() {
        // Create a JFrame (main window)
        JFrame frame = new JFrame("Contact Management Application");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 600);

        // Create a panel to hold the components and set layout to center the button and label
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout()); // Center elements in the window

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10); // Padding around components

        // Add the label for "Contact Management Application"
        

        JLabel label2 = new JLabel("<html>"
        + "<h1>Contact Management Application</h1>"
        + "</html>");
        label2.setFont(new Font("Arial", Font.BOLD, 16)); // Set font and style for the label
        panel.add(label2, gbc);
        
        // Update position for the button (below the label)
        gbc.gridy++;

        // Add the PROJ600 button as the first control to be executed
        JButton proj600Button = new JButton("PROJ600");

        
        
        
        
        // Add ActionListener to the "PROJ600" button
        proj600Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open Employee Manager window when the "PROJ600" button is clicked
                //new EmployeeManager().setVisible(true);
                new LoginScreen().setVisible(true);
                
                // Close the current window (frame)
                frame.dispose();
            }
        });

        // Add the PROJ600 button to the panel
        panel.add(proj600Button, gbc); // Center the button below the label

        // Add the panel to the frame
        frame.getContentPane().add(panel);

        // Set the frame visibility to true
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        // Run the application
        ContactManagementApp app = new ContactManagementApp();
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                app.createAndShowGUI();
            }
        });
    }
}
