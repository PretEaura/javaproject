/*Lab 8: Polymorphism
In this lab you will derive an asbtract class called Employee from the Person class and derive two concrete classes from Employee 
called Salary Employee and HourlyEmployee. The subclasses of Employee will provide different implementations of the abstract getEarnings() method.  
//Step 1: derive the two new classes SalaryEmployee and HourlyEmployee.     
 * @author ravneetkaur0125
 */
package Lab8a;

public class SalaryEmployee extends Employee { //this is new class and is inherited from Employee class
    //SalaryEmployee is a type of Employee who is a person, hence polymorphism

    // Declaring the parameters of SalaryEmployee class as per the UML
    private float monthlySalary;

    public SalaryEmployee() {
        /*Creating an empty constructor to initialize the class, though we don't need to write this explicitly 
        - complier will create on its own */
    }

    //Constructor- Adding the constructor to initialize the class 
    //- using Super keyboard to inherit properties of parent class
    public SalaryEmployee(float monthlySalary, int employeeNo, String jobDescription, String lastName, String firstName, char middleInit, String phoneNumber, Address address) {
        super(employeeNo, jobDescription, lastName, firstName, middleInit, phoneNumber, address);
        this.setMonthlySalary(monthlySalary);
    }

    //Getter for MonthlySalary field
    public float getMonthlySalary() {
        return monthlySalary;
    }

    //Setter for monthly salary field
    public void setMonthlySalary(float monthlySalary) {
        //making sure that the salary value isn't negative
        if (monthlySalary < 0) {
            this.monthlySalary = 0;
        } else {
            this.monthlySalary = monthlySalary;
        }
    }

    @Override //makes code more clear and understandable
    public double getEarnings() { //to override the getEarnings abstract method from Employee class
        double income = (monthlySalary * 12) / 26; //calculating bi-weekly earnings
        double earnings = Math.round(income * 100.0) / 100.0; //rounding off the calculated bi-weekly earnings to 2 decimal places
        return earnings;
    }
    
    @Override
    public String getEmployeeType() {
        return "Salary";
    }
}
