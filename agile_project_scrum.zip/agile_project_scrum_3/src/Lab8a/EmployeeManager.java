/*Lab 8: Polymorphism
Step 3: Modify the JFrame GUI to include weekly earnings labels and a get hours button.
 * @author ravneetkaur0125
 */
package Lab8a;

import java.util.List;
import java.sql.Timestamp;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class EmployeeManager extends javax.swing.JFrame {

    //Creates new form EmployeeManager
    //Declaring a vaiable of Employee Utilities class to access the class methods
    private EmployeeUtilities emputil;
    private JLabel jLInTime, jLOutTime;
    private JTextField txtInTime, txtOutTime;
    private JButton jBCalculateSalary, jBGenerateReport;
  
    //Constructor for the Employee Manager class to initialize the class
    public EmployeeManager() {
        
        initComponents();
        
        //Initializing the variable for Employee Utilities class
        emputil = new EmployeeUtilities();
        jLInTime = new JLabel("In Time");
        txtInTime = new JTextField();
        jLOutTime = new JLabel("Out Time");
        txtOutTime = new JTextField();
        jBCalculateSalary = new JButton("Calculate Salary");
        jBGenerateReport = new JButton("Generate Report");
        
        //Fetching the details of current employee using get Current method and storing to Employee class variable
        Employee e = emputil.getCurrent();
        //Calling the display Employee method to display the Employee details on the Jframe
        displayEmployee(e);
          
        jBCalculateSalary.addActionListener(evt -> calculateSalaryActionPerformed(evt));
        jBGenerateReport.addActionListener(evt -> generateSalaryReportActionPerformed(evt));
 
    }

    private void calculateSalaryActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            // Get the current employee
            Employee e = emputil.getCurrent();//emputil.getCurrentEmployee();

            // Save time tracking data
            String inTime = txtInTime.getText();
            String outTime = txtOutTime.getText();
            saveTimeTracking(e, inTime, outTime);

            // Calculate salary based on hours worked
            List<TimeTracking> timeData = emputil.getTimeTracking(e.getEmployeeId());
            float totalHours = 0;
            for (TimeTracking record : timeData) {
                long duration = record.getOutTime().getTime() - record.getInTime().getTime();
                totalHours += duration / (1000 * 60 * 60); // Convert milliseconds to hours
            }

            // Calculate salary
            float salary = 0;
            if (emputil.getCurrent().getEmployeeType().equals("Hourly")) {
                salary = totalHours * ((HourlyEmployee) emputil.getCurrent()).getHourlyRate();
            } else if (emputil.getCurrent().getEmployeeType().equals("Salary")) {
                salary = ((SalaryEmployee) emputil.getCurrent()).getMonthlySalary();
            }

            // Save salary data
            emputil.saveSalary(e.getEmployeeId(), totalHours, salary);
            JOptionPane.showMessageDialog(null, "Salary calculated: $" + salary, "Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error calculating salary: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveTimeTracking(Employee e, String inTime, String outTime) {
        try {
            Timestamp in = Timestamp.valueOf(inTime);
            Timestamp out = Timestamp.valueOf(outTime);
            emputil.saveTimeTracking(e.getEmployeeNo(), in, out);
            JOptionPane.showMessageDialog(null, "Time tracking data saved", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error saving time tracking: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void generateSalaryReportActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            Employee e = emputil.getCurrent();;//emputil.getCurrentEmployee();
            List<SalaryRecord> salaryData = emputil.getSalaryRecords(e.getEmployeeId());

            StringBuilder report = new StringBuilder("Salary Report for " + e.getFirstName() + " " + e.getLastName() + ":\n");
            for (SalaryRecord record : salaryData) {
                report.append("Pay Date: ").append(record.getPayDate())
                      .append(", Hours Worked: ").append(record.getHoursWorked())
                      .append(", Salary: $").append(record.getCalculatedSalary()).append("\n");
            }

            JOptionPane.showMessageDialog(null, report.toString(), "Salary Report", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error generating report: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    //Method to display the employee details on the Jframe
    public void displayEmployee(Employee e) {
        this.txtEmpNo.setText(e.getEmployeeNo() + "");//add double quotes to convert from int to string
        this.txtFirstName.setText(e.getFirstName());
        this.txtLastName.setText(e.getLastName());
        this.txtMiddleInit.setText(e.getMiddleInit() + "");//add double quotes to convert from Char to String
        this.txtPhoneNo.setText(e.getPhoneNumber());
        this.txtJobTitle.setText(e.getJobDescription());
        this.txtEarnings.setText("$" + e.getEarnings());
        if (e instanceof HourlyEmployee) { //Defining earnings based on Employee type instance
            this.jBEarnings.setText("Get Hours");
        } else if (e instanceof SalaryEmployee) {
            this.jBEarnings.setText("Get Salary");
        }

        Address a = e.getAddress();
        this.txtStreet.setText(a.getStreet());
        this.txtCity.setText(a.getCity());
        this.txtProvince.setText(a.getProvince());
        this.txtPostalCode.setText(a.getPostalCode());

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLEmpNo = new javax.swing.JLabel();
        txtEmpNo = new javax.swing.JTextField();
        jLFirstName = new javax.swing.JLabel();
        txtFirstName = new javax.swing.JTextField();
        jLLastName = new javax.swing.JLabel();
        txtLastName = new javax.swing.JTextField();
        jLMiddleInit = new javax.swing.JLabel();
        txtMiddleInit = new javax.swing.JTextField();
        jLPhoneNo = new javax.swing.JLabel();
        txtPhoneNo = new javax.swing.JTextField();
        jLStreet = new javax.swing.JLabel();
        txtStreet = new javax.swing.JTextField();
        txtCity = new javax.swing.JTextField();
        jLCity = new javax.swing.JLabel();
        txtProvince = new javax.swing.JTextField();
        jLProvince = new javax.swing.JLabel();
        txtPostalCode = new javax.swing.JTextField();
        jLPostalCode = new javax.swing.JLabel();
        jLJobTitle = new javax.swing.JLabel();
        txtJobTitle = new javax.swing.JTextField();
        jBPrevious = new javax.swing.JButton();
        jBNext = new javax.swing.JButton();
        jLEmpNo1 = new javax.swing.JLabel();
        txtInputEmpNo = new javax.swing.JTextField();
        jBSearch = new javax.swing.JButton();
        jBSave = new javax.swing.JButton();
        jLEarnings = new javax.swing.JLabel();
        txtEarnings = new javax.swing.JTextField();
        jBEarnings = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLEmpNo.setText("Employee No.");

        txtEmpNo.setText("jTextField1");

        jLFirstName.setText("First Name");

        txtFirstName.setText("jTextField1");

        jLLastName.setText("Last Name");

        txtLastName.setText("txtLastName");

        jLMiddleInit.setText("Middle Initial");

        txtMiddleInit.setText("jTextField1");

        jLPhoneNo.setText("Phone No.");

        txtPhoneNo.setText("jTextField1");

        jLStreet.setText("Street");

        txtStreet.setText("jTextField1");

        txtCity.setText("jTextField1");

        jLCity.setText("City");

        txtProvince.setText("jTextField1");

        jLProvince.setText("Province");

        txtPostalCode.setText("jTextField1");

        jLPostalCode.setText("Postal Code");

        jLJobTitle.setText("Job Title");

        txtJobTitle.setText("jTextField1");

        jBPrevious.setText("<<");
        jBPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBPreviousActionPerformed(evt);
            }
        });

        jBNext.setText(">>");
        jBNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBNextActionPerformed(evt);
            }
        });

        jLEmpNo1.setText("Employee No.");

        txtInputEmpNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtInputEmpNoActionPerformed(evt);
            }
        });

        jBSearch.setText("Search");
        jBSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBSearchActionPerformed(evt);
            }
        });

        jBSave.setText("Save");
        jBSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBSaveActionPerformed(evt);
            }
        });

        jLEarnings.setText("Earnings");

        txtEarnings.setText("jTextField1");
        txtEarnings.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEarningsActionPerformed(evt);
            }
        });

        jBEarnings.setText("Earnings");
        jBEarnings.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBEarningsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLEmpNo1)
                        .addGap(18, 18, 18)
                        .addComponent(txtInputEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jBSearch)
                        .addGap(18, 18, 18)
                        .addComponent(jBSave)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jLMiddleInit)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtMiddleInit, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLEmpNo)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(jBPrevious)
                                .addGap(38, 38, 38)
                                .addComponent(jBNext))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLFirstName)
                                .addGap(27, 27, 27)
                                .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLLastName)
                                .addGap(28, 28, 28)
                                .addComponent(txtLastName))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLPhoneNo)
                                .addGap(27, 27, 27)
                                .addComponent(txtPhoneNo, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 73, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLJobTitle)
                                            .addGap(29, 29, 29)
                                            .addComponent(txtJobTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLPostalCode)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(txtPostalCode, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(66, 66, 66)))
                                    .addGap(77, 77, 77))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLProvince)
                                            .addGap(26, 26, 26)
                                            .addComponent(txtProvince, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(116, 116, 116))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLCity)
                                            .addGap(48, 48, 48)
                                            .addComponent(txtCity, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLStreet)
                                            .addGap(37, 37, 37)
                                            .addComponent(txtStreet, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGap(79, 79, 79)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLEarnings)
                                .addGap(29, 29, 29)
                                .addComponent(txtEarnings, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)
                                .addComponent(jBEarnings, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLEmpNo)
                    .addComponent(txtEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLFirstName)
                    .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLStreet)
                    .addComponent(txtStreet, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLLastName)
                    .addComponent(txtLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLCity)
                    .addComponent(txtCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLMiddleInit)
                    .addComponent(txtMiddleInit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLProvince)
                    .addComponent(txtProvince, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLPhoneNo)
                    .addComponent(txtPhoneNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLPostalCode)
                    .addComponent(txtPostalCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLJobTitle)
                    .addComponent(txtJobTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBPrevious)
                    .addComponent(jBNext))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLEarnings)
                    .addComponent(txtEarnings, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBEarnings))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLEmpNo1)
                    .addComponent(txtInputEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBSearch)
                    .addComponent(jBSave))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBPreviousActionPerformed
        // Calling the get Previous method to return the previous employee record in the list
        Employee e = emputil.getPrevious();
        // Calling the displayEmployee method to display the returned Employee record details on the Jframe
        displayEmployee(e);
    }//GEN-LAST:event_jBPreviousActionPerformed

    private void jBNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBNextActionPerformed
        // Calling the get Next method to return the next employee record in the list
        Employee e = emputil.getNext();
        //Calling the displayEmployee method to display the returned Employee record details on the Jframe
        displayEmployee(e);
    }//GEN-LAST:event_jBNextActionPerformed

    private void jBSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBSearchActionPerformed
        // Search functionality
        try { //using try-catch blocks to handle the run time exceptions
            int id = Integer.parseInt(this.txtInputEmpNo.getText());
            // calling the getEmployeeById method to lookup the Employee id and fetch the corresponding employee details
            Employee e = emputil.getEmployeeById(id);
            //Calling the displayEmployee method to display the returned Employee record details on the Jframe
            displayEmployee(e);
        } catch (NullPointerException npe) {
            //This block will display an error message if the Employee Number is not found in the data
            JOptionPane.showMessageDialog(this, "Employee Number Was Not Found", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException nfe) {
            //this block will display an error message if the user entered Id is in incorrect format (not an integer)
            JOptionPane.showMessageDialog(this, "Employee Number should be in number format", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            //This block is for General exception- it will override all other exceptions if written first
            JOptionPane.showMessageDialog(this, "An unexpected error occured", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jBSearchActionPerformed

    private void txtInputEmpNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtInputEmpNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtInputEmpNoActionPerformed

    private void jBSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBSaveActionPerformed
        //Save functionality
        //Using a variable of type Employee to store the information for current employee
        Employee current = emputil.getCurrent(); //type employee

        //Using a variable of type Address to store the updated address information for current employee
        Address a = new Address(this.txtStreet.getText(), this.txtCity.getText(), this.txtProvince.getText(),
                this.txtPostalCode.getText());

//        Employee e=new Employee(Integer.parseInt(this.txtEmpNo.getText()),this.txtJobTitle.getText(),
//        this.txtLastName.getText(),this.txtFirstName.getText(),this.txtMiddleInit.getText().charAt(0),
//        this.txtPhoneNo.getText(),a);
        //Initializing Employee type variable with null
        Employee e = null;
        //Checking the class type of current employee and defining salary accordingly
        if (current instanceof SalaryEmployee) {
            //fetching the monhtly salary for salaried employee
            float monthlySalary = ((SalaryEmployee) current).getMonthlySalary();
            // Using a variable of type Employee to store the updated detailed information for current salaried employee
            e = new SalaryEmployee(monthlySalary, Integer.parseInt(this.txtEmpNo.getText()), this.txtJobTitle.getText(),
                    this.txtLastName.getText(), this.txtFirstName.getText(), this.txtMiddleInit.getText().charAt(0),
                    this.txtPhoneNo.getText(), a);
            //displaying confirmation message using dailog box
            JOptionPane.showMessageDialog(this, "Employee Data Updated", "Info", JOptionPane.INFORMATION_MESSAGE);
        } else if (current instanceof HourlyEmployee) { //Checking the class type of current employee and defining salary accordingly
            //fetching the hours worked and hourly rate for Hourly Employees
            float hoursWorked = ((HourlyEmployee) current).getHoursWorked();
            float hourlyRate = ((HourlyEmployee) current).getHourlyRate();
            // Using a variable of type Employee to store the updated detailed information for current hourly employee
            e = new HourlyEmployee(hourlyRate, hoursWorked, Integer.parseInt(this.txtEmpNo.getText()),
                    this.txtJobTitle.getText(),
                    this.txtLastName.getText(), this.txtFirstName.getText(), this.txtMiddleInit.getText().charAt(0),
                    this.txtPhoneNo.getText(), a);
            //displaying confirmation message using dailog box
            JOptionPane.showMessageDialog(this, "Employee Data Updated", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
        
        // Calling the Update Employee method to update the details of Employee as entered by User in Jframe
        emputil.updateEmployee(e);
        //JOptionPane.showMessageDialog(this, "Employee Data Updated", "Info", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_jBSaveActionPerformed

    private void txtEarningsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEarningsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEarningsActionPerformed

    //Method to display earnings or hours based on the employee type
    private void jBEarningsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBEarningsActionPerformed
        
        //Fetching details of the current employee
        Employee e = emputil.getCurrent();
        
        //update the text on the Dialog Box based on the kind of employee:
        if (e instanceof HourlyEmployee) {
            //Fetching hours in case of hourly employee
            float hours = ((HourlyEmployee) e).getHoursWorked();
            //Displaying hours worked in the pay period using dialog box
            JOptionPane.showMessageDialog(this, "Hours worked in this pay period: " + hours, "Hours Worked", JOptionPane.INFORMATION_MESSAGE);
        } else if (e instanceof SalaryEmployee) {
            //Fetching monthly salary in case of salary employee
            float salary = ((SalaryEmployee) e).getMonthlySalary();
            //Displaying monthly salary using dialog box
            JOptionPane.showMessageDialog(this, "Monthly Salary" + salary, "Monthly Salary", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_jBEarningsActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBEarnings;
    private javax.swing.JButton jBNext;
    private javax.swing.JButton jBPrevious;
    private javax.swing.JButton jBSave;
    private javax.swing.JButton jBSearch;
    private javax.swing.JLabel jLCity;
    private javax.swing.JLabel jLEarnings;
    private javax.swing.JLabel jLEmpNo;
    private javax.swing.JLabel jLEmpNo1;
    private javax.swing.JLabel jLFirstName;
    private javax.swing.JLabel jLJobTitle;
    private javax.swing.JLabel jLLastName;
    private javax.swing.JLabel jLMiddleInit;
    private javax.swing.JLabel jLPhoneNo;
    private javax.swing.JLabel jLPostalCode;
    private javax.swing.JLabel jLProvince;
    private javax.swing.JLabel jLStreet;
    private javax.swing.JTextField txtCity;
    private javax.swing.JTextField txtEarnings;
    private javax.swing.JTextField txtEmpNo;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtInputEmpNo;
    private javax.swing.JTextField txtJobTitle;
    private javax.swing.JTextField txtLastName;
    private javax.swing.JTextField txtMiddleInit;
    private javax.swing.JTextField txtPhoneNo;
    private javax.swing.JTextField txtPostalCode;
    private javax.swing.JTextField txtProvince;
    private javax.swing.JTextField txtStreet;
    // End of variables declaration//GEN-END:variables
}
