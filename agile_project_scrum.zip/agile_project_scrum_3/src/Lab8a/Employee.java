/*Lab 8: Polymorphism
In this lab you will derive an asbtract class called Employee from the Person class and derive two concrete classes from Employee 
called Salary Employee and HourlyEmployee. The abstract Employee class will declare an abstract method called getEarnings() 
(This is similar to the earnings() method used in chapter 10). The subclasses of Employee will provide different implementations of these methods.  
//Step 1: In a new folder, create a modified version Employee class that derives from Person.  
The new version is abstract and defines an abstract method called getEarnings.  
 * @author ravneetkaur0125
 */
package Lab8a;

public abstract class Employee extends Person { //this is abstract class and the Employee class is inherited from Person class
    //Employee is a person

    // Declaring the parameters of Employee class as per the UML
    private int employeeNo;
    private String jobDescription;

    public Employee() {
        /*Creating an empty constructor to initialize the class, though we don't need to write this explicitly 
        - complier will create on its own */
        //super(); - this will call parent class constructor: it will intialize the parent class
    }

    //Constructor- Adding the constructor to initialize the class 
    //- using Super keyboard to inherit properties of parent class
    public Employee(int employeeNo, String jobDescription, String lastName, String firstName, char middleInit, String phoneNumber, Address address) {
        super(lastName, firstName, middleInit, phoneNumber, address);
        this.employeeNo = employeeNo;
        this.jobDescription = jobDescription;
    }

    //Getter for Employee Number field
    public int getEmployeeNo() {
        return employeeNo;
    }

     //Getter for Employee Id field
    public int getEmployeeId() {
        return this.employeeNo;//need to work 
    }
    
    //Setter for Employee Number field
    public void setEmployeeNo(int employeeNo) {
        this.employeeNo = employeeNo;
    }

    //Getter for Employee Job Description field
    public String getJobDescription() {
        return jobDescription;
    }

    //Setter for Employee Job Description field
    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    //Getter for Employee Number combined with full name field with definition converted to String type
    public String toString() {
        return getEmployeeNo() + ", " + getFullName();
    }

    //declare an abstract method called getEarnings()
    public abstract double getEarnings();
    
    // Abstract method to be implemented by subclasses
    public abstract String getEmployeeType();
}
