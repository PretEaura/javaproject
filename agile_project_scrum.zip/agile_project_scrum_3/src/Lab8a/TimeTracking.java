/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab8a;
import java.sql.Timestamp;
/**
 *
 * @author Preetul
 */

public class TimeTracking {
    private int id;
    private int employeeId;
    private Timestamp inTime;
    private Timestamp outTime;

    // Constructor
    public TimeTracking(int id, int employeeId, Timestamp inTime, Timestamp outTime) {
        this.id = id;
        this.employeeId = employeeId;
        this.inTime = inTime;
        this.outTime = outTime;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public Timestamp getInTime() {
        return inTime;
    }

    public void setInTime(Timestamp inTime) {
        this.inTime = inTime;
    }

    public Timestamp getOutTime() {
        return outTime;
    }

    public void setOutTime(Timestamp outTime) {
        this.outTime = outTime;
    }

    @Override
    public String toString() {
        return "TimeTracking{" +
                "id=" + id +
                ", employeeId=" + employeeId +
                ", inTime=" + inTime +
                ", outTime=" + outTime +
                '}';
    }
}

