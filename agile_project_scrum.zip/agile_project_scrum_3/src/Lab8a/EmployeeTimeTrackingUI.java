/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab8a;

import javax.swing.*;
import javax.swing.text.DateFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

public class EmployeeTimeTrackingUI extends JFrame {
    private JSpinner inTimeSpinner;
    private JSpinner outTimeSpinner;
    private JButton saveButton;
    private JButton backButton;

    public EmployeeTimeTrackingUI() {
        setTitle("Employee Time Tracking");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 300);
        setLayout(new GridLayout(6, 2)); // Adjusted layout for an additional row

        // Add Labels and Input Fields
        add(new JLabel("Employee ID:"));
        JTextField empIdField = new JTextField();
        add(empIdField);

        add(new JLabel("In Time:"));
        inTimeSpinner = createDateTimeSpinner();
        add(inTimeSpinner);

        add(new JLabel("Out Time:"));
        outTimeSpinner = createDateTimeSpinner();
        add(outTimeSpinner);

        // Add Buttons
        saveButton = new JButton("Save Time Tracking");
        add(saveButton);

        backButton = new JButton("Back");
        add(backButton);

        // Add Action Listeners
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveTimeTracking(Integer.parseInt(empIdField.getText()));
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Closes the current window
            }
        });

        setVisible(true);
    }

    private JSpinner createDateTimeSpinner() {
        JSpinner spinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editor = new JSpinner.DateEditor(spinner, "yyyy-MM-dd HH:mm:ss");
        DateFormatter formatter = (DateFormatter) editor.getTextField().getFormatter();
        formatter.setAllowsInvalid(false); // Prevent invalid input
        formatter.setOverwriteMode(true);
        spinner.setEditor(editor);
        return spinner;
    }

    private void saveTimeTracking(int empId) {
        try {
            System.out.println("Hi");
            Date inTime = (Date) inTimeSpinner.getValue();
            Date outTime = (Date) outTimeSpinner.getValue();

            if (inTime.after(outTime)) {
                JOptionPane.showMessageDialog(this, "In Time must be before Out Time.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Timestamp inTimestamp = new Timestamp(inTime.getTime());
            Timestamp outTimestamp = new Timestamp(outTime.getTime());

            System.out.println("Employee ID: " + empId);
            System.out.println("In Time: " + inTimeSpinner.getValue());
            System.out.println("Out Time: " + outTimeSpinner.getValue());

            // Call saveTimeTracking method from EmployeeUtilities
            EmployeeUtilities empUtil = new EmployeeUtilities();
            empUtil.saveTimeTracking(empId, inTimestamp, outTimestamp);

            JOptionPane.showMessageDialog(this, "Time Tracking Saved Successfully!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new EmployeeTimeTrackingUI();
    }
}
